    <object id="Player"
                          classid="CLSID:22D6f312-B0F6-11D0-94AB-0080C74C7E95"
                       codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,4,7,1112"
                              standby="Loading Microsoft Windows Media Player Components..."
                              type="application/x-oleobject"
                              width="300"
                              heights="50">
                     <!--<param name="Filename" value='demo_channel_load.jsp?channel_id=40'>-->
                    
                    <param name="Filename" value="mms://221.243.63.170/RadioNepal?sesid=224686623-572169289614394198" />
                     <param name="ShowControls" value="true">
                     <param name="ShowAudioControls" value="true">
                     <param name="AutoStart" value="true" />
                     <param name="ShowVideoControls" value="true">
                     <PARAM name="Volume" value="100">
                     <param name="fullScreen" value="true" />

                     <param name="ShowStatusBar" value="true">
                     <param name="AnimationAtStart" value="false">
                     <param name='NOLABELS' value='true'>
                     <PARAM NAME="ClickToPlay" value="false">
                    <param name="EnableContextMenu" value="false">
                     <param NAME="Scale" VALUE="ShowAll">
                     <param name="Zoom" value="true">
                     <param name="uiMode" value="full">
                     <param name="Enabled" value="true">

                     
                    <embed type="application/x-mplayer2" src='mms://221.243.63.170/RadioNepal?sesid=224686623-572169289614394198' name="MediaPlayer"
                          width="300"
                          height="50"
                          pluginspage="http://www.microsoft.com/isapi/redir.dll?prd=windows&amp;sbp=mediaplayer&amp;ar=media&amp;sba=plugin&amp;" autosize="1" autostart="1" showcontrols="1" showdisplay="0" showstatusbar="1" enablecontextmenu="0">                        
                     </embed>
                
  </object>
