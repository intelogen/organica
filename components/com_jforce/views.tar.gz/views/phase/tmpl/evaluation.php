<?php

/************************************************************************************
*	@package		Joomla															*
*	@subpackage		jForce, the Joomla! CRM											*
*	@version		2.0																*
*	@file			results.php														*
*	@updated		2008-12-15														*
*	@copyright		Copyright (C) 2008 - 2009 Extreme Joomla. All rights reserved.	*
*	@license		GNU/GPL, see jforce.license.php									*
************************************************************************************/

// no direct access
defined('_JEXEC') or die('Restricted access');	
?>
<?php JHTMLBehavior::formvalidation(); ?>
<script language="javascript">
function myValidate(f) {
        if (document.formvalidator.isValid(f)) {
                f.check.value='<?php echo JUtility::getToken(); ?>';//send token
                return true; 
        }
        else {
                alert('Please fill the fields with appropriate information');
        }
        return false;
}
</script>
    <!-- Stylesheet for tables -->
    <style>
        table.allleft{
            text-align:left;
            border:1px solid #EFEFEF;
        }
        table.allleft th{
            border:1px solid #DDD;
            padding:4px;
            background-color:#EEE;
        }
        table.allleft tr,
        table.allleft td { padding:4px; }
        
      </style>
      <!-- Stylesheet for tables -->


<div class='contentheading'><?php echo JText::_('End evaluation for the phase'); ?></div>

<!-- Step 1 -->

<form method="post" action="<?=$this->step_action_link;?>" onSubmit="return myValidate(this)">
<?php echo JHTML::_( 'form.token' ); ?>
<input type="hidden" name="step_redirection_link" value="<?=$this->step_redirection_link; ?>" >
<input type="hidden" name="phase_id" value="<?=$this->phase_id ?>" >
        
<div class='tabContainer2'>
    <div>
        <h3>Phase End Survey  </h3>
    </div>
    <table>
		<tbody>
            <?php
                foreach($this->survey_questions as $q){
                    ?>
                        <tr>
                            <td width="77%"><p class="style1"><?=$q->question;?></p>
                            </td>
                            <td bgcolor="#fff9d2" width="23%"><p class="style1">
                                    <input type="radio" name="evaluation[end][<?=$q->variable;?>]" value="Y"/>
                                    Yes    <input type="radio" name="evaluation[end][<?=$q->variable;?>]" value="N" />
                                    No</p>
                            </td>
                        </tr>
                    <?
                }
                
                if(!count($this->survey_questions)){
                    ?>
                    <tr>
                        <td colspan=2 style='color:red;font-size:15px;'>
                            There aren't any survey questions for this phase. 
                        </td>
                    </tr>
                    <?
                }
            ?>
            <!--
            <tr>
                <td><p class="style1">Do you have normal bowel movements of solid consistency?</p>
                </td>
                <td bgcolor="#fff9d2"><p class="style1">
                        <input type="radio" id="Radio36" name="evaluation[end][diabetes]" value="Y"/>
                        Yes<input type="radio" id="Radio49" name="evaluation[end][diabetes]" value="N"/>
                        No</p>
                </td>
            </tr>
            <tr>
                <td><p class="style1">Are you going to the bathroom at least 1 good complete evacuation 
                        or better 2 to 3 per day?</p>
                </td>
                <td bgcolor="#fff9d2"><p class="style1">
                        <input type="radio" id="Radio37" name="evaluation[end][endocrine]" value="Y"/>
                        Yes<input type="radio" id="Radio48" name="evaluation[end][endocrine]" value="N"/>
                        No</p>
                </td>
            </tr>
            <tr>
                <td><p class="style1">Is your average pH of 3 to 5 samplings in the normal range 
                        between 6.8 and 7.4?
                    </p>
                </td>
                <td bgcolor="#fff9d2"><p class="style1">
                        <input type="radio" id="Radio38" name="evaluation[end][hypertension]" value="Y"/>
                        Yes<input type="radio" id="Radio47" name="evaluation[end][hypertension]" value="N"/>
                        No</p>
                </td>
            </tr>
            <tr>
                <td><p class="style1">Are you tired and lethargic?
                    </p>
                </td>
                <td bgcolor="#fff9d2"><p class="style1">
                        <input type="radio" id="Radio39" name="evaluation[end][lipid]" value="Y"/>
                        Yes<input type="radio" id="Radio46" name="evaluation[end][lipid]" value="N"/>
                        No</p>
                </td>
            </tr>
            <tr>
                <td><p class="style1">Are you eating 5 to 7 small meals per day consistently?
                    </p>
                </td>
                <td bgcolor="#fff9d2"><p class="style1">
                        <input type="radio" id="Radio40" name="evaluation[end][cardiovascular]" value="Y"/>
                        Yes<input type="radio" id="Radio45" name="evaluation[end][cardiovascular]" value="N"/>
                        No</p>
                </td>
            </tr>
            -->
        </tbody>
    </table>
</div>	
<div>
    &nbsp;
</div>
<!-- Step 2 -->
<!--
<div class="tabContainer2">
    <div>
        <h3>Retake Body Score Survey</h3>
    </div>
    <table>
        
    </table>
</div>
<div>
    &nbsp;
</div>
-->
<!-- Step 3 -->
<div class="tabContainer2">
    <div>
        <h3>
            Retake Intake Survey
        </h3>
    </div>
    <table>
        <tr>
            <td valign="top" align="center" colspan="3"><div align="left">
                    <table width="277" border="0" align="center">
                        <tbody><tr>
                            <td width="72"><b><a target="_blank">Weight</a></b></td>
                            <td width="318"><input type="text" style="width: 50px;" tabindex="1" id="txtWeight" value="" name="evaluation[intake][W]" class="inputbox required validate-numeric"/>
                                <strong>lbs</strong></td>
                        </tr>
                        <tr>
                            <td><b><a target="_blank">Body Fat</a></b></td>
                            <td><input type="text" style="width: 50px;" tabindex="2" id="txtBodyFat" value="" name="evaluation[intake][F]" class="inputbox required validate-numeric"/>
                            <strong>%</strong></td>
                        </tr>
                        <tr>
                            <td><b><a target="_blank">PH Score</a></b></td>
                            <td><input type="text" style="width: 50px;" tabindex="3" id="txtPHScore" value="" name="evaluation[intake][PH]" class="inputbox required validate-numeric"/></td>
                        </tr>
                    </tbody></table>
                </div>
            </td>
        </tr>
    </table>
</div>
<div>
    &nbsp;
</div>
<!-- Step 4 -->
<div class="tabContainer2">
    <h3>Phase End Photo</h3>
    <div>
        
        <?php 
            if ($this->phase_details->endphoto):
                // display link to phase end photo upload form
                echo "<div style='font-size:15px;color:#008;'>
                            <img src=\"{$this->phase_details->endphoto}\" />
                </div>";
            else :
                echo "<div style='font-size:15px;color:#800;'>
                        End photo for this phase has not been uploaded. 
                        <br />
                        <a href=\"{$this->phase_details->upload_link}\" target='_blank'>Upload Photo</a> or <a href=\"{$this->phase_details->refresh_link}\">Refresh this page </a>.
                </div>";
            endif;                                                                
        ?>
    </div>    
</div>
<div>
    &nbsp;
</div>
<!-- Step 4 -->
<div class="tabContainer2">
    <h3>Update Tracking</h3>
    <style>
        .subtitle{
            font-size:15px;color:#008;
        }
    </style>
    <?
    $options = "<option value='same'>Same</option>
        <option value='eliminated'>Eliminated</option>
        <option value='better'>Better</option>
        <option value='new'>New</option>
        ";
    ?>
    <br />
    <div class='subtitle'>
        Symptoms Tracking
    </div>
    <div>
        <table class="allleft" width="100%">
            <tr>
                <th width="150">Symptoms</th><th>Status</th><th>Notes</th>
            </tr>
        <?php        
            foreach($this->tracking->symptoms as $s){
                $options_html = "<select name=\"tracking[symptoms][$s->variable][status]\">
                                {$options}
                            </select>
                            ";
                ?>
                    <tr>
                        <td><?=$s->question;?></td><td><?=$options_html;?></td><td><input type='text' name="tracking[symptoms][<?=$s->variable?>][notes]"></td>
                    </tr>
                <?
            }
        ?>
        </table>
    </div>
    <br />
    <div class='subtitle'>
        Medical Tracking
    </div>
    <div>
        <table class="allleft" width="100%">
            <tr>
                <th width="150">Medtrack</th><th>Status</th><th>Notes</th>
            </tr>
        <?php        
            foreach($this->tracking->medtrack as $s){
                $options_html = "<select name=\"tracking[medtrack][$s->variable][status]\">
                                {$options}
                            </select>
                            ";
                ?>
                    <tr>
                        <td><?=$s->question;?></td><td><?=$options_html;?></td><td><input type='text' name="tracking[medtrack][<?=$s->variable?>][notes]"></td>
                    </tr>
                <?
            }
        ?>
        </table>
    </div>
    <br />
    <div class='subtitle'>
        Diseases Tracking
    </div>    
    <div>
        <table class="allleft" width="100%">
            <tr>
                <th width="150">Diseases</th><th>Status</th><th>Notes</th>
            </tr>
        <?php        
            foreach($this->tracking->diseases as $s){
                $options_html = "<select name=\"tracking[diseases][$s->variable][status]\">
                                {$options}
                            </select>
                            ";
                ?>
                    <tr>
                        <td><?=$s->question;?></td><td><?=$options_html;?></td><td><input type='text' name="tracking[diseases][<?=$s->variable?>][notes]"></td>
                    </tr>
                <?
            }
        ?>
        </table>
    </div>
</div>

<br />
<div class="tabContainer2">
    <input type="hidden" name="form_type" value="evaluation">
    <input type="submit" value="Mark Step as Completed">
</div>

</form>