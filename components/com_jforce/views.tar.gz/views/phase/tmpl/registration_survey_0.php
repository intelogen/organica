<?php

/************************************************************************************
*    @package        Joomla                                                            *
*    @subpackage        jForce, the Joomla! CRM                                            *
*    @author        Dhruba,JTPL
*    @license        GNU/GPL, see jforce.license.php                                    *
************************************************************************************/

// no direct access
defined('_JEXEC') or die('Restricted access');    
?>

<div class='contentheading'><?php echo JText::_('What are you looking for ?'); ?></div>
<div class='tabContainer2'>
    <form action="<?=JRoute::_("index.php?option=com_jforce&view=phase&task=registration_survey_0&layout=registration_survey_1");?>" method="post">
     <table width=100%>
        <tbody style="margin-left:10px;width:auto;">
            <tr>
                <td>
                    Please tell us a little about what you wish to accomplish...
                </td>
            </tr>
            <tr>
                <td style="width: 154px;">
                </td>
            </tr>
            <?php
                foreach($this->looking_for_questions as $q):
                ?>
                    <tr>
                        <td style="width: 154px;">
                            <span style="width: 150px;"><input type="checkbox" name="lookingfor[]" value="<?=$q->variable;?>" id="chk<?=$q->variable;?>"/><label for="<?=$q->variable;?>"><?=$q->question;?></label></span></td>
                    </tr>        
                <?
                endforeach;
            ?>
            <tr>
                <td>
                    <input type="submit" value="Next Step">
                </td>
            </tr>
        </tbody>
     </table>
     </form>
</div>
